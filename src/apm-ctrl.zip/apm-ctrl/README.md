# APM-controller
Modifying Px4 controller to adapt to APM Firmware

# 使用说明
- [APM-controller](#apm-controller)
- [使用说明](#使用说明)
  - [概述](#概述)
  - [固件烧录](#固件烧录)
  - [飞控固件参数调试](#飞控固件参数调试)
  - [使用apm\_controller](#使用apm_controller)

## 概述
该仓库内容为Px4 controller的适用于APM（也即ardupilot）的版本。使用APM固件的原因有二： 
(1) 组里最近使用得较多的Kakute H7V2或Kakute Mini飞控无法烧录Px4固件(最近潘能刚刚成功在Kakute Mini飞控上烧录Px4，但使用体验不佳)； 
(2)APM固件支持双向Dshot，这可以提高电机转速反馈频率的上限，适用于需要电机转速反馈的使用场景(不过最近Px4似乎也要支持双向Dshot了)。
简而言之，如果你使用的是Kakute H7V2或Kakute Mini飞控，抑或需要高频电机转速反馈，建议使用APM固件。

## 固件烧录
此处以Kakute系列飞控的固件烧录为例。首先，使用Stm32CubeProgrammer软件烧录Bootloader.Bootloader可从(https://firmware.ardupilot.org/Copter/stable-4.3.5/)下载。 注意，Kakute H7V1飞控对应版本为KakuteH7-bdshot; Kakute H7V1对应版本为KakuteH7v2; Kakute H7Mini对应版本为KakuteH7Mini-Nand。进入以上网址的对应目录，下载arducopter_with_bl.hex文件，按住飞控的Reset进入DFU 模式，最后使用Stm32CubeProgrammer软件进行烧录即可。此时，Bootloader与飞控固件都已经成功烧录了，打开QGC或Mission Planner等地面站就已经可以与飞控成功连接。如果需要使用自行修改的飞控，则无需再刷bootloader，直接在QGC里烧录编译固件生成的apj文件即可（本仓库中也存放了Kakute H7 V1、V2与Mini的修改过的固件，该版本支持电机转速控制，具体使用详见[FAST_NMPC_Controller](https://github.com/ZJU-FAST-Lab/UAV_NMPC_Real)）.修改过的固件源码我放在了Nas的Public/设备使用教程/飞控源码和虚拟机 这一目录中，大家如果需要编译适用于别的飞控的固件，或者需要进行二次开发，可以参考（所有修改过的地方全局搜索zrb和wyz就可以看到）。注意不要外传。

## 飞控固件参数调试
固件烧录成功后，为调试好飞机，达到手控性能，同时能够正确与上位机通信，需要进行相应的固件参数调整。具体参考[帆神写的文档](https://charmyoung.notion.site/APM-697b52589579465991e380da97c71c61#f20fdc5555d44b1fba0b05fae0ea1c65)。其中，最值得注意的是：(1) GUID_OPTIONS 需要设置为 9; (2) 遥控器的Channel5的上、中、下三个模式分别设置为Stabilize, Stabilize, 与Guided_Nogps; (3) MOT_THST_EXPO建议设置为0，这意味着飞控完全使用线性油门模型，这样的话px4_controller中的hover_percentage直接设置为悬停油门值即可。为便于参考，我分别留存了一份默认固件与支持电机转速的修改后的固件的参数，见/firmware_and_params/firmware_customized与/firmware_and_params/firmware_origin目录。注意，不要全部copy这些参数，因为飞控方向、电机转向、pid参数等这些数据都是因机而异的。

## 使用apm_controller
由于apm和px4对于mavros的支持都很完善，因此，不需要对px4_controller做很大修改。需要修改的只有PX4CtrlFSM.cpp下的state_data.state_before_offboard.mode的话题名而已。修改过的版本见src/apmctrl目录。具体使用逻辑与方法上也与px4controller无异，也同样支持姿态控制与角速度控制模式，具体参考[px4controller的文档](https://github.com/ZJU-FAST-Lab/PX4-controller/tree/master/src/px4ctrl)即可。不过，mavros建议使用修改过的版本，见mavros_modified.zip压缩包，启动mavros的脚本为src/sh/mavros.sh，如果运行成功，imu与电机转速的反馈频率均有333Hz。

## 安装依赖
sudo apt-get install ros-noetic-mavros