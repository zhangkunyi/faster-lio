#include "outputCtrl.h"
#include <quadrotor_msgs/TakeoffLand.h>

bool OutputCtrl::inspectionCommandService(px4ctrl::InspectionCommand::Request  &req,
                                          px4ctrl::InspectionCommand::Response &res)
{
    InspectionCmd_t cmd = static_cast<InspectionCmd_t>(req.command);
    switch(cmd)
    {
        case InspectionCmd_t::TAKEOFF:
        {
            ROS_INFO("[apm ctrl] Take off Command is received!");
            if(inspection_status_ == InspectionStatus_t::STANDBY)
            {
                quadrotor_msgs::TakeoffLand takeoff_land_msg;
                takeoff_land_msg.takeoff_land_cmd = 1;
                apm_cmd_pub_.publish(takeoff_land_msg);
                res.success = true;
            }
            else
            {
                res.success = false;
                res.error_message = "[apm ctrl] Inspection status is not STANDBY !";
            }
            break;         
        }
        case InspectionCmd_t::LAND:
        {
            ROS_INFO("[apm ctrl] Land Command is received!");
            if(inspection_status_ == InspectionStatus_t::INSPECTING ||
               inspection_status_ == InspectionStatus_t::PAUSE ||
               inspection_status_ == InspectionStatus_t::RETURN)
            {
                taskPlannerCommandClient(TaskPlannerCommand::PAUSE);
                quadrotor_msgs::TakeoffLand takeoff_land_msg;
                takeoff_land_msg.takeoff_land_cmd = 2;
                apm_cmd_pub_.publish(takeoff_land_msg);
                res.success = true;
            }
            else
            {
                res.success = false;
                res.error_message = "[apm ctrl] Check status is inpecting/pause/return!";
            }
            break;
        }
        case InspectionCmd_t::PAUSE:
        {
            ROS_INFO("[apm ctrl] Pause Command is received!");
            if(inspection_status_==InspectionStatus_t::INSPECTING || inspection_status_==InspectionStatus_t::RETURN)
            {
                taskPlannerCommandClient(TaskPlannerCommand::PAUSE);
                setInspectionStatus(InspectionStatus_t::PAUSE);
                res.success = true;
            }
            else
            {
                res.success = false;
                res.error_message = "[apm ctrl] Check status is inpecting/return!";               
            }
            break;
        }
        case InspectionCmd_t::RETURN:
        {
            ROS_INFO("[apm ctrl] Return Command is received!");
            if(inspection_status_==InspectionStatus_t::INSPECTING || inspection_status_ == InspectionStatus_t::PAUSE)
            {
                taskPlannerCommandClient(TaskPlannerCommand::RETURN);
                setInspectionStatus(InspectionStatus_t::RETURN);
                res.success = true;
            }
            else
            {
                res.success = false;
                res.error_message = "[apm ctrl] Check status is inpecting/pause!";                  
            }
            break;
        }
        case InspectionCmd_t::RECOVER:
        {
            ROS_INFO("[apm ctrl] Recover Command is received!");
            if(inspection_status_==InspectionStatus_t::PAUSE)
            {
                taskPlannerCommandClient(TaskPlannerCommand::RECOVER);
                setInspectionStatus(InspectionStatus_t::INSPECTING);
                res.success = true;
            }
            else
            {
                res.success = false;
                res.error_message = "[apm ctrl] Check status is pause!";   
            }
            break;
        }
        default:
        {
            ROS_ERROR("[apm ctrl] Command is not recognized!!");
            res.success = false;
            break;
        }
    }
    return true;
}

// void OutputCtrl::resetCallback(const std_msgs::StringPtr reset_name)
// {
//     inspection_name_ = reset_name.data;
//     if()
//     setInspectionStatus(InspectionStatus_t::STANDBY);
//     taskPlannerCommandClient(TaskPlannerCommand::START);
// }

void OutputCtrl::inspectionCommandCallback(const std_msgs::UInt8Ptr cmd_id)
{
    InspectionCmd_t cmd = static_cast<InspectionCmd_t>(cmd_id->data);
    switch(cmd)
    {
        case InspectionCmd_t::TAKEOFF:
        {
            ROS_INFO("[apm ctrl] Take off Command is received!");
            if(inspection_status_ == InspectionStatus_t::STANDBY)
            {
                quadrotor_msgs::TakeoffLand takeoff_land_msg;
                takeoff_land_msg.takeoff_land_cmd = 1;
                apm_cmd_pub_.publish(takeoff_land_msg);
            }
            else
            {
                ROS_WARN("[apm ctrl] Inspection status is not STANDBY !");
            }
            break;         
        }
        case InspectionCmd_t::LAND:
        {
            ROS_INFO("[apm ctrl] Land Command is received!");
            if(inspection_status_ == InspectionStatus_t::PAUSE)
            {
                quadrotor_msgs::TakeoffLand takeoff_land_msg;
                takeoff_land_msg.takeoff_land_cmd = 2;
                apm_cmd_pub_.publish(takeoff_land_msg);
            }
            else
            {
                ROS_WARN("[apm ctrl] Check status is pause!");
            }
            break;
        }
        case InspectionCmd_t::PAUSE:
        {
            ROS_INFO("[apm ctrl] Pause Command is received!");
            if(inspection_status_==InspectionStatus_t::INSPECTING || inspection_status_==InspectionStatus_t::RETURN)
            {
                taskPlannerCommandClient(TaskPlannerCommand::PAUSE);
                setInspectionStatus(InspectionStatus_t::PAUSE);
            }
            else
            {
                ROS_WARN("[apm ctrl] Check status is inpecting/return!");               
            }
            break;
        }
        case InspectionCmd_t::RETURN:
        {
            ROS_INFO("[apm ctrl] Return Command is received!");
            if(inspection_status_==InspectionStatus_t::INSPECTING || inspection_status_ == InspectionStatus_t::PAUSE)
            {
                taskPlannerCommandClient(TaskPlannerCommand::RETURN);
                setInspectionStatus(InspectionStatus_t::RETURN);
            }
            else
            {
                ROS_WARN("[apm ctrl] Check status is inpecting/pause!");                  
            }
            break;
        }
        case InspectionCmd_t::RECOVER:
        {
            ROS_INFO("[apm ctrl] Recover Command is received!");
            if(inspection_status_==InspectionStatus_t::PAUSE)
            {
                taskPlannerCommandClient(TaskPlannerCommand::RECOVER);
                setInspectionStatus(InspectionStatus_t::INSPECTING);
            }
            else
            {
                ROS_WARN("[apm ctrl] Check status is pause!");   
            }
            break;
        }
        default:
        {
            ROS_ERROR("[apm ctrl] Command is not recognized!!");
            break;
        }
    }
    return;
}

void OutputCtrl::batteryStatusCallback(const sensor_msgs::BatteryStatePtr battery_status)
{
    std_msgs::Float32 battery_voltage;
    battery_voltage.data = battery_status->voltage;
    battery_status_pub_.publish(battery_voltage);
}

void OutputCtrl::publishInspectionStatus(const ros::TimerEvent & /*event*/)
{
    std_msgs::String inspection_status;
    if(inspection_status_ == InspectionStatus_t::INSPECTING)
    { 
        if(task_planner_status_ == "return")
        {
            inspection_status_ = InspectionStatus_t::RETURN;
        }
        else if(task_planner_status_ == "inspecting")
        {
            inspection_status_ = InspectionStatus_t::INSPECTING;
        }
    }
    switch(inspection_status_)
    {
        case InspectionStatus_t::STANDBY:
        {
            inspection_status.data = "standby";
            break;
        }
        case InspectionStatus_t::TAKEOFF:
        {
            inspection_status.data = "takeoff";
            break;
        }
        case InspectionStatus_t::LAND:
        {
            inspection_status.data = "land";
            break;
        }
        case InspectionStatus_t::INSPECTING:
        {
            inspection_status.data = "inspecting";
            break;
        }
        case InspectionStatus_t::PAUSE:
        {
            inspection_status.data = "pause";
            break;
        }
        case InspectionStatus_t::RETURN:
        {
            inspection_status.data = "return";
            break;
        }
        case InspectionStatus_t::FINISHED:
        {
            inspection_status.data = "finished";
            break;
        }
        default:
            break;
    }

    inspection_status_pub_.publish(inspection_status);
}

void OutputCtrl::taskPlannerStatusCallback(const std_msgs::StringPtr status)
{
	task_planner_status_ = status->data;
}

bool OutputCtrl::taskPlannerCommandClient(const TaskPlannerCommand & cmd)
{
    task_planner::TaskPlannerCommand srv;
    switch(cmd)
    {
        case TaskPlannerCommand::START:
        {
            ROS_INFO("[apm ctrl] Command ego planner start.");
            srv.request.command = static_cast<uint8_t>(TaskPlannerCommand::START);
            break;
        }
        case TaskPlannerCommand::PAUSE:
        {
            ROS_INFO("[apm ctrl] Command ego planner pause.");
            srv.request.command = static_cast<uint8_t>(TaskPlannerCommand::PAUSE);
            break;
        }
        case TaskPlannerCommand::RECOVER:
        {
            ROS_INFO("[apm ctrl] Command ego planner recover.");
            srv.request.command = static_cast<uint8_t>(TaskPlannerCommand::RECOVER);
            break;
        }
        case TaskPlannerCommand::RETURN:
        {
            ROS_INFO("[apm ctrl] Command ego planner return.");
            srv.request.command = static_cast<uint8_t>(TaskPlannerCommand::RETURN);
            break;
        }
        default:
            break;
    }
    if (task_planner_cmd_client_.call(srv))
    {
        ROS_INFO("Command: %ld", (bool)srv.response.success);
        return true;
    }
    else
    {
        ROS_ERROR("Failed to call service task_planner_cmd");
        return false;
    }
}

