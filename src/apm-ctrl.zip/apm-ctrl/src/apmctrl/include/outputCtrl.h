#pragma once

#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/UInt8.h>
#include <std_msgs/Float32.h>
#include <quadrotor_msgs/TakeoffLand.h>
#include <task_planner/TaskPlannerCommand.h>

#include <px4ctrl/InspectionCommand.h>
#include <sensor_msgs/BatteryState.h>

enum class TaskPlannerCommand
{
    RESET,
    START,
    PAUSE,
    RECOVER,
    RETURN
};

enum class InspectionCmd_t
{
    UNKOWN,
    TAKEOFF,
    PAUSE,
    RECOVER,
    RETURN,
    LAND
};

enum class InspectionStatus_t
{
    STANDBY,
    TAKEOFF,
    INSPECTING,
    PAUSE,
    RETURN,
    LAND,
    FINISHED
};

class OutputCtrl
{
public:
    OutputCtrl() = default;
    ~OutputCtrl() = default;
    void init(ros::NodeHandle & nh)
    {
        apm_cmd_pub_ = nh.advertise<quadrotor_msgs::TakeoffLand>("/px4ctrl/takeoff_land", 10);
        inspection_status_pub_ = nh.advertise<std_msgs::String>("/inspection_status", 10);
        error_pub_ = nh.advertise<std_msgs::String>("/error_status", 10);
        battery_status_pub_ = nh.advertise<std_msgs::Float32>("/battery_status", 10);
        task_planner_cmd_client_ = nh.serviceClient<task_planner::TaskPlannerCommand>("/drone_0_planner_node/task_planner_cmd");
        inspection_cmd_server_ = nh.advertiseService("inspection_command_service", &OutputCtrl::inspectionCommandService, this);
        task_planner_status_sub_ = nh.subscribe("/task_planner/status", 10, &OutputCtrl::taskPlannerStatusCallback, this);
        inspection_cmd_sub_ = nh.subscribe("/inspection_command", 10, &OutputCtrl::inspectionCommandCallback, this);
        battery_status_sub_ = nh.subscribe("/mavros/battery", 10, &OutputCtrl::batteryStatusCallback, this);
        // reset_cmd_sub_ = nh.subscribe("/reset_command", 10, &OutputCtrl::resetCallback, this);
        inspection_status_pub_cycle_ = nh.createTimer(ros::Duration(0.2), &OutputCtrl::publishInspectionStatus, this);
        setInspectionStatus(InspectionStatus_t::STANDBY);
    }

    void setInspectionStatus(InspectionStatus_t status) {  
        ROS_INFO("Set inspection status %d.", status);
        inspection_status_ = status;  };
        // get inspection command from high level

    /***************publish to drone******************/
    ros::Timer inspection_status_pub_cycle_;
    ros::Subscriber task_planner_status_sub_;
    ros::Subscriber inspection_cmd_sub_;
    ros::Subscriber battery_status_sub_;

    ros::Publisher apm_cmd_pub_;
    ros::Publisher battery_status_pub_;
    ros::Publisher inspection_status_pub_;
    ros::Publisher error_pub_;

    ros::ServiceClient task_planner_cmd_client_;
    ros::ServiceServer inspection_cmd_server_;

    void taskPlannerStatusCallback(const std_msgs::StringPtr status);
    bool taskPlannerCommandClient(const TaskPlannerCommand & cmd);
    std::string get_task_planner_status(){return task_planner_status_;}
    void publishInspectionStatus(const ros::TimerEvent & /*event*/);
    void inspectionCommandCallback(const std_msgs::UInt8Ptr cmd_id);
    void batteryStatusCallback(const sensor_msgs::BatteryStatePtr battery_status);
    // void resetCallback(const std_msgs::StringPtr reset_name);

private:
    bool inspectionCommandService(px4ctrl::InspectionCommand::Request  &req, px4ctrl::InspectionCommand::Response &res);
    InspectionStatus_t inspection_status_;
    std::string task_planner_status_;
    double battery_capacity_;
    std::string inspection_name_;
};