for i in 1 2 3;
do
	hdparm -tT /dev/mmcblk0;
done;
