sudo ./scrips/max_cpu_freq.sh;
sudo ./scrips/max_emc_freq.sh;
sudo ./scrips/max_gpu_freq.sh;

ODOM_TOPIC="/corrected_imu_propagate_odom"

roslaunch realsense2_camera rs_camera.launch & sleep 1;
roslaunch mavros px4.launch & sleep 10;
rosrun vins vins_node $(pwd)/realflight_modules/VINS-Fusion-gpu/config/px4/stereo_imu_config_3331.yaml & sleep 1;
roslaunch odom_correction uwb_correction.launch & sleep 1;

roslaunch px4ctrl run_ctrl.launch odom_topic:=$ODOM_TOPIC & sleep 1;

roslaunch ego_planner run_in_exp_3331.launch odom_topic:=$ODOM_TOPIC & sleep 1;

# roslaunch swarm_bridge bridge_tcp_drone.launch & sleep 1;

wait;
