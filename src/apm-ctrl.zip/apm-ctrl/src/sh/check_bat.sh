roslaunch mavros px4.launch & sleep 10;
roslaunch px4ctrl run_ctrl.launch & sleep 1;

wait;
