service ntp stop
ntpdate  10.1.1.30
hwclock -w
service ntp start
