sudo ./scrips/max_cpu_freq.sh;
sudo ./scrips/max_emc_freq.sh;
sudo ./scrips/max_gpu_freq.sh;
sudo chmod 777 /dev/ttyTHS0
sudo chmod 777 /dev/ttyTHS1
sudo chmod 777 /dev/ttyTHS4

ODOM_TOPIC="/corrected_imu_propagate_odom"

#./mavros.sh & sleep 20;
# roslaunch realsense2_camera rs_camera.launch & sleep 5;
#rosrun mavros mavcmd long 511 105 2500 0 0 0 0 0 & sleep 2;
#rosrun mavros mavcmd long 511 31 2500 0 0 0 0 0 & sleep 2;
rosrun vins vins_node $(pwd)/realflight_modules/VINS-Fusion-gpu/config/px4/stereo_imu_config.yaml & sleep 5;
roslaunch odom_correction uwb_correction.launch & sleep 5;
roslaunch drone_detect drone_detect.launch odom_topic:=$ODOM_TOPIC & sleep 1;
roslaunch px4ctrl run_ctrl.launch odom_topic:=$ODOM_TOPIC & sleep 3;

roslaunch ego_planner run_in_exp.launch odom_topic:=$ODOM_TOPIC & sleep 3;

# roslaunch swarm_bridge bridge_tcp_drone.launch & sleep 1;

wait;
