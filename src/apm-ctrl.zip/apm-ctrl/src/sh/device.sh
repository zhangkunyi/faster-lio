#!/bin/bash

roslaunch realsense2_camera rs_camera.launch & sleep 15;

CURRENT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]:-${(%):-%x}}" )" >/dev/null 2>&1 && pwd )"
PASSWD="nv"
source ${CURRENT_DIR}/../devel/setup.bash

echo ${PASSWD} | sudo -S chmod +777 /dev/ttyTHS1
roslaunch mavros apm.launch > log 2>&1 & sleep 5;

rosrun mavros mavsys message_interval --id=245  --rate=5;
rosrun mavros mavsys message_interval --id=147  --rate=5;
rosrun mavros mavsys message_interval --id=30   --rate=150;
rosrun mavros mavsys message_interval --id=27   --rate=250;
rosrun mavros mavsys message_interval --id=65   --rate=10;
rosrun mavros mavsys message_interval --id=36   --rate=30;

#rosrun mavros mavsys message_interval --id=11030 --rate=333;
#rosrun mavros mavsys message_interval --id=36    --rate=333;

echo FINISHED

wait;
