#!/bin/bash
#CURRENT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]:-${(%):-%x}}" )" >/dev/null 2>&1 && pwd )"
PASSWD="nv"
#source ${CURRENT_DIR}/devel/setup.bash

echo ${PASSWD} | sudo -S chmod +777 /dev/ttyTHS1
echo ${PASSWD} | sudo -S chmod +777 /dev/ttyTHS0
echo ${PASSWD} | sudo -S chmod +777 /dev/ttyTHS4
roslaunch mavros apm.launch & sleep 10;

rosrun mavros mavsys message_interval --id=245  --rate=5;
rosrun mavros mavsys message_interval --id=147  --rate=5;
rosrun mavros mavsys message_interval --id=30   --rate=333;
rosrun mavros mavsys message_interval --id=27   --rate=333;
rosrun mavros mavsys message_interval --id=65   --rate=100;
rosrun mavros mavsys message_interval --id=11030 --rate=333;
rosrun mavros mavsys message_interval --id=36    --rate=333;
rosrun mavros mavsys message_interval --id=385    --rate=333;
wait;
