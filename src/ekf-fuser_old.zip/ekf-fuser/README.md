# EKF fuser

`EKF fuser` is an Iterative Extended Kalman Filter node that fuses `IMU topic` and `Odometry topic`. The code in this repository mainly supports the following features:

* `IMU topic` provides high-frequency accelerator and gyroscope measurements in the IMU frame
* `Odometry topic` provides low-frequency measurements of the position and orientation of the body frame in the gravity frame
* estimate the high-frequency position, orientation, and velocity of the IMU frame in the gravity frame
* estimate extrinsic parameter between the IMU frame and the body frame from odometry
* develop based on [IKFoM](https://github.com/hku-mars/IKFoM)

## System frame definition

* > $\mathcal{W}$ : the world frame(inertial)
* > $\mathcal{G}$ : the gravity frame(inertial)
* > $\mathcal{I}$ : the IMU frame(non-inertial)
* > $\mathcal{B}$ : the body frame(non-inertial)

## System state definition

The system state has 23 dimensions, which are defined as follows:
>$ \chi = \{ {}^{\mathcal{G}} \boldsymbol{p} ^{\mathcal{G}}_{\mathcal{I}},~
              {}^{\mathcal{G}}_{\mathcal{I}} \mathbf{R},~
              {}^{\mathcal{I}}_{\mathcal{B}} \mathbf{R},~
              {}^{\mathcal{I}} \boldsymbol{t} ^{\mathcal{I}}_{\mathcal{B}},~
              {}^{\mathcal{G}} \boldsymbol{v} ^{\mathcal{G}}_{\mathcal{I}},~
              {}^{\mathcal{I}} \boldsymbol{b_a},~
              {}^{\mathcal{I}} \boldsymbol{b_g},~
              {}^{\mathcal{G}} \boldsymbol{g}
   \} $

* > $ {}^{\mathcal{G}} \boldsymbol{p} ^{\mathcal{G}}_{\mathcal{I}} $ : the position of the IMU frame in the world frame
* > $ {}^{\mathcal{G}}_{\mathcal{I}} \mathbf{R} $ : the orientation of the IMU frame in the world frame
* > $ {}^{\mathcal{I}}_{\mathcal{B}} \mathbf{R} $ : the orientation of the body frame in the IMU frame
* > $ {}^{\mathcal{I}} \boldsymbol{t} ^{\mathcal{I}}_{\mathcal{B}} $ : the position of the body frame in the IMU frame
* > $ {}^{\mathcal{G}} \boldsymbol{v} ^{\mathcal{G}}_{\mathcal{I}} $ : the velocity of the IMU frame in the world frame
* > $ {}^{\mathcal{I}} \boldsymbol{b_a} $ : the acclerator boldsymbol{b} of IMU snesor in the IMU frame
* > $ {}^{\mathcal{I}} \boldsymbol{b_g} $ : the gyroscope boldsymbol{b} of IMU snesor in the IMU frame
* > $ {}^{\mathcal{G}} \boldsymbol{g} $ : the gravity vector in the world frame

## IMU process model

IMU measurements include the non-gravitational acceleration $\widetilde{\boldsymbol{a}}$ and gyroscope $\widetilde{\boldsymbol{\omega}}$, which are measured in the IMU frame (centered on the IMU sensor with a triaxial sequence of Front-Left-Up) and given by:

* > ${^{\mathcal{I}}}\widetilde{\boldsymbol{a}} =
     {_{\mathcal{I}}^{\mathcal{G}}}\mathbf{R}^\top ({^{\mathcal{G}}}{\boldsymbol{a}} + {^{\mathcal{G}}}\boldsymbol{\boldsymbol{g}} ) +  
     {^{\mathcal{I}}}{\boldsymbol{b_a}} + {\boldsymbol{n_a}}$
* > ${^{\mathcal{I}}}\widetilde{\boldsymbol{\omega}} =
     {^{\mathcal{I}}}{\boldsymbol{\omega}} + {^{\mathcal{I}}}{\boldsymbol{b_g}} + {\boldsymbol{n_g}}$

where ${^{\mathcal{G}}}{\boldsymbol{a}}$ is the true acceleration in the gravity-aligned frame(with z-axis pointing up vertically), ${^{\mathcal{I}}}{\boldsymbol{\omega}}$ is the true angular velocity in $\mathcal{I}$ frame, ${^{\mathcal{G}}}\boldsymbol{\boldsymbol{g}} = [0,0,-9.8 m/s^2]$ is the gravity vector in ${\mathcal{G}}$ frame, ${\boldsymbol{n_a}}$ and ${\boldsymbol{n_g}}$ are the additive Gaussian white noise in acceleration and gyroscope measurements, ${\boldsymbol{b_a}}$ and ${\boldsymbol{b_g}}$ are the biases of IMU modeled as random walks:

* > ${\boldsymbol{n_a}} \sim \mathcal{N}(0,{\boldsymbol{\Sigma}}_{\boldsymbol{a}}^2), \quad \dot{\boldsymbol{b}}_{\boldsymbol{a}} = {\boldsymbol{n}_{{\boldsymbol{b}}_{\boldsymbol{a}}}} \sim \mathcal{N}(0,{\boldsymbol{\Sigma}}_{\boldsymbol{b_a}}^2)$

* > ${\boldsymbol{n_g}} \sim \mathcal{N}(0,{\boldsymbol{\Sigma}}_{\boldsymbol{\omega}}^2), \quad \dot{\boldsymbol{b}}_{\boldsymbol{\omega}} = {\boldsymbol{n}_{{\boldsymbol{b}}_{\boldsymbol{\omega}}}} \sim \mathcal{N}(0,{\boldsymbol{\Sigma}}_{\boldsymbol{b_g}}^2)$

where ${\boldsymbol{\Sigma}}_*^2$ is the Covariance corresponding to each Gaussian distribution respectively.

## system observation model[^1]

### position observation model

The position measurements from the odometry topic can be expressed as:

> ${^{\mathcal{G}}}\boldsymbol{\widetilde{p}}{^{\mathcal{G}}_{\mathcal{B}}}
= \mathbf{H}_p(\boldsymbol{x}, \boldsymbol{n}_{\boldsymbol{p}})
= {^{\mathcal{G}}}\boldsymbol{p}{^{\mathcal{G}}_{\mathcal{I}}} + {_{\mathcal{I}}^{\mathcal{G}}}\mathbf{R} {^{\mathcal{I}}}\boldsymbol{t}{^{\mathcal{I}}_{\mathcal{B}}} + \boldsymbol{n}_{\boldsymbol{p}},$

whose jacobian can be given as:

> $\frac{\partial \mathbf{H}_{\boldsymbol{p}}}
      {\partial {\boldsymbol{x}}_{k}} =
\begin{bmatrix}
    \mathbf{I}_{3\times3}
   &-\lfloor {^{\mathcal{I}}}\boldsymbol{t}{^{\mathcal{I}}_{\mathcal{B}}} \rfloor _\times
   &\mathbf{0}_{3\times3}
   &{_{\mathcal{I}}^{\mathcal{G}}}\mathbf{R}
   &\mathbf{0}_{3\times3}
   &\mathbf{0}_{3\times3}
   &\mathbf{0}_{3\times3}
   &\mathbf{0}_{3\times2}
\end{bmatrix}_{3\times23},$

and the noise of network displacement measurements is $\boldsymbol{n}_{\boldsymbol{p}} \sim \mathcal{N}(0,{\boldsymbol{\Sigma}}_{\boldsymbol{p}}^2)$.

### Orientation observation model

The orientation measurements from the odometry topic can be expressed as:

> ${^{\mathcal{G}}_{\mathcal{B}}} \mathbf{\widetilde{R}}
= \mathbf{H}_o(\boldsymbol{x}, \boldsymbol{n}_{\boldsymbol{o}})
= {_{\mathcal{I}}^{\mathcal{G}}}\mathbf{R}
  {_{\mathcal{B}}^{\mathcal{I}}}\mathbf{R}  + \boldsymbol{n}_{\boldsymbol{o}},$

whose jacobian can be given as:

> $\frac{\partial \mathbf{H}_{\boldsymbol{o}}}
        {\partial {\boldsymbol{x}}_{k}} =
\begin{bmatrix}
    \mathbf{0}_{3\times3}
   &{_{\mathcal{B}}^{\mathcal{I}}}\mathbf{R}^{-1}
   &\mathbf{I}_{3\times3}
   &\mathbf{0}_{3\times3}
   &\mathbf{0}_{3\times3}
   &\mathbf{0}_{3\times3}
   &\mathbf{0}_{3\times3}
   &\mathbf{0}_{3\times2}
\end{bmatrix}_{3\times23},$

and the noise of network displacement measurements is $\boldsymbol{n}_{\boldsymbol{o}} \sim \mathcal{N}(0,{\boldsymbol{\Sigma}}_{\boldsymbol{o}}^2)$.

[^1]: The derivation of the Jacobi matrix associated with $\mathbb{SO}(3)$ group is defined in subsection 4.2 of the literature: [Quaternion kinematics for the error-state Kalman filter](https://arxiv.org/pdf/1711.02508.pdf)
