#include "use-ikfom.hpp"
#include "so3_math.h"

namespace ekf_fuser {

    MTK::get_cov<ProcessNoiseIkfom>::type process_noise_cov() {
        MTK::get_cov<ProcessNoiseIkfom>::type cov = MTK::get_cov<ProcessNoiseIkfom>::type::Zero();
        MTK::setDiagonal<ProcessNoiseIkfom, vect3, 0>(cov, &ProcessNoiseIkfom::ng, 0.0001);  // 0.03
        MTK::setDiagonal<ProcessNoiseIkfom, vect3, 3>(cov, &ProcessNoiseIkfom::na,
                                                        0.0001);  // *dt 0.01 0.01 * dt * dt 0.05
        MTK::setDiagonal<ProcessNoiseIkfom, vect3, 6>(cov, &ProcessNoiseIkfom::nbg,
                                                        0.00001);  // *dt 0.00001 0.00001 * dt *dt 0.3 //0.001 0.0001 0.01
        MTK::setDiagonal<ProcessNoiseIkfom, vect3, 9>(cov, &ProcessNoiseIkfom::nba,
                                                        0.00001);  // 0.001 0.05 0.0001/out 0.01
        return cov;
    }

    MTK::get_cov<MeasurementNoiseIkfom>::type measurement_noise_cov() {
        MTK::get_cov<MeasurementNoiseIkfom>::type cov = MTK::get_cov<MeasurementNoiseIkfom>::type::Zero();
        MTK::setDiagonal<MeasurementNoiseIkfom, vect3, 0>(cov, &MeasurementNoiseIkfom::pos, 0.0001);
        MTK::setDiagonal<MeasurementNoiseIkfom, vect3, 3>(cov, &MeasurementNoiseIkfom::rot, 0.0001);
        return cov;
    }

    Eigen::Matrix<double, 24, 1> f(StateIkfom &s, const InputIkfom &in) {
        Eigen::Matrix<double, 24, 1> res = Eigen::Matrix<double, 24, 1>::Zero();
        vect3 omega;
        in.gyro.boxminus(omega, s.bg);
        vect3 a_inertial = s.rot * (in.acc - s.ba);
        for (int i = 0; i < 3; i++) {
            res(i) = s.vel[i];
            res(i + 3) = omega[i];
            res(i + 12) = a_inertial[i] + s.grav[i];
        }
        return res;
    }

    Eigen::Matrix<double, 24, 23> df_dx(StateIkfom &s, const InputIkfom &in) {
        Eigen::Matrix<double, 24, 23> cov = Eigen::Matrix<double, 24, 23>::Zero();
        cov.template block<3, 3>(0, 12) = Eigen::Matrix3d::Identity();
        vect3 acc_;
        in.acc.boxminus(acc_, s.ba);
        vect3 omega;
        in.gyro.boxminus(omega, s.bg);
        cov.template block<3, 3>(12, 3) = -s.rot.toRotationMatrix() * MTK::hat(acc_);
        cov.template block<3, 3>(12, 18) = -s.rot.toRotationMatrix();
        Eigen::Matrix<StateIkfom::scalar, 2, 1> vec = Eigen::Matrix<StateIkfom::scalar, 2, 1>::Zero();
        Eigen::Matrix<StateIkfom::scalar, 3, 2> grav_matrix;
        s.S2_Mx(grav_matrix, vec, 21);
        cov.template block<3, 2>(12, 21) = grav_matrix;
        cov.template block<3, 3>(3, 15) = -Eigen::Matrix3d::Identity();
        return cov;
    }

    Eigen::Matrix<double, 24, 12> df_dw(StateIkfom &s, const InputIkfom &in) {
        Eigen::Matrix<double, 24, 12> cov = Eigen::Matrix<double, 24, 12>::Zero();
        cov.template block<3, 3>(12, 3) = -s.rot.toRotationMatrix();
        cov.template block<3, 3>(3, 0) = -Eigen::Matrix3d::Identity();
        cov.template block<3, 3>(15, 6) = Eigen::Matrix3d::Identity();
        cov.template block<3, 3>(18, 9) = Eigen::Matrix3d::Identity();
        return cov;
    }

    MeasurementIkfom h(StateIkfom &s, bool &valid)
    {
        if (false){ valid = false; } // other conditions could be used to stop the ekf update iteration before convergence, otherwise the iteration will not stop until the condition of convergence is satisfied.
        MeasurementIkfom h_;
        h_.pos = s.pos + s.rot.toRotationMatrix() * s.offset_T_L_I;
        h_.rot = s.rot.toRotationMatrix() * s.offset_R_L_I.toRotationMatrix();
        return h_;
    }

    Eigen::Matrix<double, MeasurementIkfom::DOF, StateIkfom::DOF> dh_dx(StateIkfom &s, bool &valid)
    {
        Eigen::Matrix<double, MeasurementIkfom::DOF, StateIkfom::DOF> dh_dx_ = Eigen::Matrix<double, MeasurementIkfom::DOF, StateIkfom::DOF>::Zero();
        dh_dx_.block<3, 3>(0, 0) = Eigen::Matrix3d::Identity();
        dh_dx_.block<3, 3>(0, 3) = -SKEW_SYM_MATRIX(s.offset_T_L_I);
        dh_dx_.block<3, 3>(0, 9) = s.rot.toRotationMatrix();

        dh_dx_.block<3, 3>(3, 3) = s.offset_R_L_I.toRotationMatrix().transpose();
        dh_dx_.block<3, 3>(3, 6) = Eigen::Matrix3d::Identity();

        return dh_dx_;
    }

    Eigen::Matrix<double, MeasurementIkfom::DOF, MeasurementNoiseIkfom::DOF> dh_dv(StateIkfom &s, bool &valid)
    {
        Eigen::Matrix<double, MeasurementIkfom::DOF, MeasurementNoiseIkfom::DOF> dh_dv_ = Eigen::Matrix<double, MeasurementIkfom::DOF, MeasurementNoiseIkfom::DOF>::Zero();
        dh_dv_.block<3, 3>(0, 0) = Eigen::Matrix3d::Identity();
        dh_dv_.block<3, 3>(3, 3) = Eigen::Matrix3d::Identity();
        return dh_dv_;
    }

    vect3 SO3ToEuler(const SO3 &orient) {
        Eigen::Matrix<double, 3, 1> _ang;
        Eigen::Vector4d q_data = orient.coeffs().transpose();
        // scalar w=orient.coeffs[3], x=orient.coeffs[0], y=orient.coeffs[1], z=orient.coeffs[2];
        double sqw = q_data[3] * q_data[3];
        double sqx = q_data[0] * q_data[0];
        double sqy = q_data[1] * q_data[1];
        double sqz = q_data[2] * q_data[2];
        double unit = sqx + sqy + sqz + sqw;  // if normalized is one, otherwise is correction factor
        double test = q_data[3] * q_data[1] - q_data[2] * q_data[0];

        if (test > 0.49999 * unit) {  // singularity at north pole

            _ang << 2 * std::atan2(q_data[0], q_data[3]), M_PI / 2, 0;
            double temp[3] = {_ang[0] * 57.3, _ang[1] * 57.3, _ang[2] * 57.3};
            vect3 euler_ang(temp, 3);
            return euler_ang;
        }
        if (test < -0.49999 * unit) {  // singularity at south pole
            _ang << -2 * std::atan2(q_data[0], q_data[3]), -M_PI / 2, 0;
            double temp[3] = {_ang[0] * 57.3, _ang[1] * 57.3, _ang[2] * 57.3};
            vect3 euler_ang(temp, 3);
            return euler_ang;
        }

        _ang << std::atan2(2 * q_data[0] * q_data[3] + 2 * q_data[1] * q_data[2], -sqx - sqy + sqz + sqw),
            std::asin(2 * test / unit),
            std::atan2(2 * q_data[2] * q_data[3] + 2 * q_data[1] * q_data[0], sqx - sqy - sqz + sqw);
        double temp[3] = {_ang[0] * 57.3, _ang[1] * 57.3, _ang[2] * 57.3};
        vect3 euler_ang(temp, 3);
        // euler_ang[0] = roll, euler_ang[1] = pitch, euler_ang[2] = yaw
        return euler_ang;
    }
}