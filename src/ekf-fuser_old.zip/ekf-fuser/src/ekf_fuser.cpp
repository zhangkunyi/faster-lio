
#include "ekf_fuser.hpp"
#include "use-ikfom.hpp"

namespace ekf_fuser{
    EKFFuser::EKFFuser(ros::NodeHandle &handle)
    {
        measures_.imu_.clear();
        
        //initialize kf
        std::vector<double> epsi(23, 0.001);

        // todo 
        kf_.init(f, df_dx, df_dw, h, dh_dx, dh_dv, 100, epsi.data());

        //initialize imu
        double gyr_cov, acc_cov, b_gyr_cov, b_acc_cov;
        StateCovInit init_state_cov;
        std::vector<double> extrinT{3, 0.0};
        std::vector<double> extrinR{9, 0.0};
        common::V3D lidar_T_wrt_IMU;
        common::M3D lidar_R_wrt_IMU;

        p_imu_.reset(new ekf_fuser::ImuProcess());
        handle.param<double>("imu/gyr_cov", gyr_cov, 0.1);
        handle.param<double>("imu/acc_cov", acc_cov, 0.1);
        handle.param<double>("imu/b_gyr_cov", b_gyr_cov, 0.0001);
        handle.param<double>("imu/b_acc_cov", b_acc_cov, 0.0001);
        handle.param<std::vector<double>>("imu/extrinsic_T", extrinT, std::vector<double>());
        handle.param<std::vector<double>>("imu/extrinsic_R", extrinR, std::vector<double>());
            /**********init status cov***********/
        handle.param<std::vector<double>>("init_state_cov/position", init_state_cov.position, std::vector<double>());
        handle.param<std::vector<double>>("init_state_cov/rotation", init_state_cov.rotation, std::vector<double>());
        handle.param<std::vector<double>>("init_state_cov/extrinsic_R_L_I", init_state_cov.extrinsic_R_L_I, std::vector<double>());
        handle.param<std::vector<double>>("init_state_cov/extrinsic_T_L_I", init_state_cov.extrinsic_T_L_I, std::vector<double>());
        handle.param<std::vector<double>>("init_state_cov/velocity", init_state_cov.velocity, std::vector<double>());
        handle.param<std::vector<double>>("init_state_cov/bg", init_state_cov.bg, std::vector<double>());
        handle.param<std::vector<double>>("init_state_cov/ba", init_state_cov.ba, std::vector<double>());
        handle.param<std::vector<double>>("init_state_cov/gravity", init_state_cov.gravity, std::vector<double>());

        lidar_T_wrt_IMU = common::VecFromArray<double>(extrinT);
        lidar_R_wrt_IMU = common::MatFromArray<double>(extrinR);
        p_imu_->SetExtrinsic(lidar_T_wrt_IMU, lidar_R_wrt_IMU);
        p_imu_->SetGyrCov(common::V3D(gyr_cov, gyr_cov, gyr_cov));
        p_imu_->SetAccCov(common::V3D(acc_cov, acc_cov, acc_cov));
        p_imu_->SetGyrBiasCov(common::V3D(b_gyr_cov, b_gyr_cov, b_gyr_cov));
        p_imu_->SetAccBiasCov(common::V3D(b_acc_cov, b_acc_cov, b_acc_cov));
        p_imu_->SetInitStateCov(init_state_cov);
        p_imu_->InitQ();

        std::string measure_topic, imu_topic;
        handle.param<std::string>("common/measurement_topic", measure_topic, "/measurement");
        handle.param<std::string>("common/imu_topic", imu_topic, "/livox/imu");

        sub_kf_   = handle.subscribe(measure_topic, 1, &EKFFuser::MeasureCallBack, this, ros::TransportHints().tcpNoDelay());
        sub_imu_  = handle.subscribe(imu_topic, 10, &EKFFuser::IMUCallBack,  this, ros::TransportHints().tcpNoDelay());

        pub_odom_ = handle.advertise<nav_msgs::Odometry>("/ekf_fuser/odom", 10);
        pub_state_ = handle.advertise<KF>("/ekf_fuser/kf", 10);
    }

    /****************ROS-Related function*********************/
    void EKFFuser::MeasureCallBack(const nav_msgs::Odometry::ConstPtr & odom_msg)
    {
        have_lidar_odom_ = true;

        double kf_msg_time = odom_msg->header.stamp.toSec();

        StateIkfom x_updated;
        StateCov P_updated;
        MeasurementIkfom z;
        z.pos << odom_msg->pose.pose.position.x,
                 odom_msg->pose.pose.position.y,
                 odom_msg->pose.pose.position.z;

        z.rot.coeffs() << odom_msg->pose.pose.orientation.x,
                          odom_msg->pose.pose.orientation.y,
                          odom_msg->pose.pose.orientation.z,
                          odom_msg->pose.pose.orientation.w;

        MeasurementNoiseCov measure_noise_cov;
        measure_noise_cov = measurement_noise_cov(); // get cov from z
        kf_.update_iterated(z, measure_noise_cov);
        x_updated = kf_.get_x();
        P_updated = kf_.get_P();
        publishState(x_updated, P_updated, kf_msg_time);
    }

    void EKFFuser::publishState(const StateIkfom & x, const StateCov & P, double time_stamp)
    {
        KF state_msg;
        state_msg.header.stamp = ros::Time().fromSec(time_stamp);
        state_msg.pos[0] = x.pos[0];
        state_msg.pos[1] = x.pos[1];
        state_msg.pos[2] = x.pos[2];
        state_msg.rot[0] = x.rot.w();
        state_msg.rot[1] = x.rot.x();
        state_msg.rot[2] = x.rot.y();
        state_msg.rot[3] = x.rot.z();
        state_msg.offset_R_L_I[0] = x.offset_R_L_I.w();
        state_msg.offset_R_L_I[1] = x.offset_R_L_I.x();
        state_msg.offset_R_L_I[2] = x.offset_R_L_I.y();
        state_msg.offset_R_L_I[3] = x.offset_R_L_I.z();
        state_msg.offset_T_L_I[0] = x.offset_T_L_I[0];
        state_msg.offset_T_L_I[1] = x.offset_T_L_I[1];
        state_msg.offset_T_L_I[2] = x.offset_T_L_I[2];
        state_msg.vel[0] = x.vel[0];
        state_msg.vel[1] = x.vel[1];
        state_msg.vel[2] = x.vel[2];
        state_msg.bg[0] = x.bg[0];
        state_msg.bg[1] = x.bg[1];
        state_msg.bg[2] = x.bg[2];
        state_msg.ba[0] = x.ba[0];
        state_msg.ba[1] = x.ba[1];
        state_msg.ba[2] = x.ba[2];
        state_msg.grav[0] = x.grav[0];
        state_msg.grav[1] = x.grav[1];
        state_msg.grav[2] = x.grav[2];
        auto P_data = P.data();
        int size = 23 * 23 - 1;
        for( int i = 0; i < size; i++ )
        {
            state_msg.P[i] = P_data[i];
        }
        pub_state_.publish(state_msg);   
    }

    void EKFFuser::IMUCallBack(const sensor_msgs::Imu::ConstPtr &msg_in) 
    {
        p_imu_->Process(measures_, kf_);

        sensor_msgs::Imu::Ptr msg(new sensor_msgs::Imu(*msg_in));

        msg->header.stamp = ros::Time().fromSec(timediff_lidar_wrt_imu_ + msg_in->header.stamp.toSec());

        double timestamp = msg->header.stamp.toSec();

        measures_.imu_.push_back(msg);
        if( measures_.imu_.size() > MAX_IMU_COUNT_ )
            measures_.imu_.pop_front();

        nav_msgs::Odometry odom_pub_msg;
        p_imu_->PropogateOnce(measures_, kf_, have_lidar_odom_);
        if( have_lidar_odom_ )
        {
            // common::V3D pos;
            // pos[0] = odom_pub_msg.pose.pose.position.x;
            // pos[1] = odom_pub_msg.pose.pose.position.y;
            // pos[2] = odom_pub_msg.pose.pose.position.z;

            // filter(odom_pub_msg, pos);
            publishOdom(odom_pub_msg);
        }
    }

    void EKFFuser::publishOdom(nav_msgs::Odometry & odom_pub_msg)
    {
        odom_pub_msg.header.frame_id = "world";
        odom_pub_msg.child_frame_id = "body";
        odom_pub_msg.header.stamp = ros::Time().fromSec(p_imu_->GetTimeStamp());
        auto P = kf_.get_P();

        for (int i = 0; i < 6; i ++)
        {
            odom_pub_msg.pose.covariance[i*6 + 0] = P(i, 0);
            odom_pub_msg.pose.covariance[i*6 + 1] = P(i, 1);
            odom_pub_msg.pose.covariance[i*6 + 2] = P(i, 2);
            odom_pub_msg.pose.covariance[i*6 + 3] = P(i, 3);
            odom_pub_msg.pose.covariance[i*6 + 4] = P(i, 4);
            odom_pub_msg.pose.covariance[i*6 + 5] = P(i, 5);
        }

        for (int i = 0; i < 6; i ++)
        {
            odom_pub_msg.twist.covariance[i*6 + 0] = P(12 + i, 12);
            odom_pub_msg.twist.covariance[i*6 + 1] = P(12 + i, 13);
            odom_pub_msg.twist.covariance[i*6 + 2] = P(12 + i, 14);
            odom_pub_msg.twist.covariance[i*6 + 3] = 0;
            odom_pub_msg.twist.covariance[i*6 + 4] = 0;
            odom_pub_msg.twist.covariance[i*6 + 5] = 0;
        }
        StateIkfom imu_state = p_imu_->GetImuState();
        common::V3D angvel_last = p_imu_->GetAngVel();

        odom_pub_msg.pose.pose.orientation.w = imu_state.rot.w();
        odom_pub_msg.pose.pose.orientation.x = imu_state.rot.x();
        odom_pub_msg.pose.pose.orientation.y = imu_state.rot.y();
        odom_pub_msg.pose.pose.orientation.z = imu_state.rot.z();
        odom_pub_msg.pose.pose.position.x = imu_state.pos(0);
        odom_pub_msg.pose.pose.position.y = imu_state.pos(1);
        odom_pub_msg.pose.pose.position.z = imu_state.pos(2);

        odom_pub_msg.twist.twist.linear.x = imu_state.vel(0);
        odom_pub_msg.twist.twist.linear.y = imu_state.vel(1);
        odom_pub_msg.twist.twist.linear.z = imu_state.vel(2);
        odom_pub_msg.twist.twist.angular.x = angvel_last(0);
        odom_pub_msg.twist.twist.angular.y = angvel_last(1);
        odom_pub_msg.twist.twist.angular.z = angvel_last(2);
        pub_odom_.publish(odom_pub_msg);
    }

    /**************Non-ROS function************/

    void EKFFuser::filter(nav_msgs::Odometry &odom_fake_ekf, common::V3D pos)
    {
        common::V3D pos_center_filter;

        double cutoff_freq = 20.0;
        double sample_freq = 200;
        double freq = sample_freq / cutoff_freq;
        double ohm = tan(M_PI / freq);
        double c = 1.0 + 2.0 * cos(M_PI / 4.0) * ohm + ohm * ohm;
        double b0 = ohm * ohm / c;
        double b1 = 2.0 * b0;
        double b2 = b0;
        double a1 = 2.0 * (ohm * ohm - 1.0) / c;
        double a2 = (1.0 - 2.0 * cos(M_PI / 4.0) * ohm + ohm * ohm) / c;

        common::V3D current_pos_center = pos - a1 * last_pos_center_ - a2 * last_last_pos_center_;
        pos_center_filter = b0 * current_pos_center + b1 * last_pos_center_ + b2 * last_last_pos_center_;
        last_last_pos_center_ = last_pos_center_;
        last_pos_center_ = current_pos_center;

        odom_fake_ekf.pose.pose.position.x = pos_center_filter(0);
        odom_fake_ekf.pose.pose.position.y = pos_center_filter(1);
        odom_fake_ekf.pose.pose.position.z = pos_center_filter(2);
    }
};
