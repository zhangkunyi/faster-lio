#include <ros/assert.h>
#include "imu_processing.hpp"

namespace ekf_fuser
{
    ImuProcess::ImuProcess() : b_first_frame_(true), imu_need_init_(true) {
        init_iter_num_ = 1;
        Q_ = process_noise_cov();
        cov_acc_ = common::V3D(0.1, 0.1, 0.1);
        cov_gyr_ = common::V3D(0.1, 0.1, 0.1);
        cov_bias_gyr_ = common::V3D(0.0001, 0.0001, 0.0001);
        cov_bias_acc_ = common::V3D(0.0001, 0.0001, 0.0001);
        mean_acc_ = common::V3D(0, 0, -1.0);
        mean_gyr_ = common::V3D(0, 0, 0);
        angvel_last_ = common::Zero3d;
        Init_IMU_POS_ = common::Zero3d;
        Lidar_T_wrt_IMU_ = common::Zero3d;
        Lidar_R_wrt_IMU_ = common::Eye3d;
        last_imu_.reset(new sensor_msgs::Imu());
    }

    ImuProcess::~ImuProcess() {}

    void ImuProcess::Process(const common::MeasureGroup &meas, ESKF &kf_state)
    {
        if (meas.imu_.empty()) {
            return;
        }

        if (imu_need_init_) {
            /// The very first lidar frame
            IMUInit(meas, kf_state, init_iter_num_);

            imu_need_init_ = true;

            last_imu_ = meas.imu_.back();

            StateIkfom imu_state = kf_state.get_x();
            if (init_iter_num_ > MAX_INI_COUNT) {
                cov_acc_ *= pow(common::G_m_s2 / mean_acc_.norm(), 2);
                imu_need_init_ = false;

                cov_acc_ = cov_acc_scale_;
                cov_gyr_ = cov_gyr_scale_;
            }

            return;
        }
    }

    void ImuProcess::Reset() {
        mean_acc_ = common::V3D(0, 0, -1.0);
        mean_gyr_ = common::V3D(0, 0, 0);
        angvel_last_ = common::Zero3d;
        imu_need_init_ = true;
        init_iter_num_ = 1;
        v_imu_.clear();
        IMUpose_.clear();
        last_imu_.reset(new sensor_msgs::Imu());
    }

    void ImuProcess::SetInitPos(const common::V3D &pos) { Init_IMU_POS_ = pos; }

    void ImuProcess::SetExtrinsic(const common::V3D &transl, const common::M3D &rot) {
        Lidar_T_wrt_IMU_ = transl;
        Lidar_R_wrt_IMU_ = rot;
    }

    void ImuProcess::SetGyrCov(const common::V3D &scaler) { cov_gyr_scale_ = scaler; }

    void ImuProcess::SetAccCov(const common::V3D &scaler) { cov_acc_scale_ = scaler; }

    void ImuProcess::SetGyrBiasCov(const common::V3D &b_g) { cov_bias_gyr_ = b_g; }

    void ImuProcess::SetAccBiasCov(const common::V3D &b_a) { cov_bias_acc_ = b_a; }

    void ImuProcess::SetInitStateCov(const StateCovInit &state_cov) { init_state_cov_ = state_cov; }

    StateIkfom ImuProcess::GetImuState() {return imu_state_; }

    common::V3D ImuProcess::GetAngVel() {return angvel_last_; }

    double ImuProcess::GetTimeStamp() {return current_time_stamp_sec; }

    void ImuProcess::IMUInit(const common::MeasureGroup &meas, ESKF &kf_state, int &N) {
        /** 1. initializing the gravity_, gyro bias, acc and gyro covariance
         ** 2. normalize the acceleration measurenments to unit gravity_ **/

        common::V3D cur_acc, cur_gyr;

        if (b_first_frame_) {
            Reset();
            N = 1;
            b_first_frame_ = false;
            const auto &imu_acc = meas.imu_.front()->linear_acceleration;
            const auto &gyr_acc = meas.imu_.front()->angular_velocity;
            mean_acc_ << imu_acc.x, imu_acc.y, imu_acc.z;
            mean_gyr_ << gyr_acc.x, gyr_acc.y, gyr_acc.z;
        }

        for (const auto &imu : meas.imu_) {
            const auto &imu_acc = imu->linear_acceleration;
            const auto &gyr_acc = imu->angular_velocity;
            cur_acc << imu_acc.x, imu_acc.y, imu_acc.z;
            cur_gyr << gyr_acc.x, gyr_acc.y, gyr_acc.z;

            mean_acc_ += (cur_acc - mean_acc_) / N;
            mean_gyr_ += (cur_gyr - mean_gyr_) / N;

            cov_acc_ =
                cov_acc_ * (N - 1.0) / N + (cur_acc - mean_acc_).cwiseProduct(cur_acc - mean_acc_) * (N - 1.0) / (N * N);
            cov_gyr_ =
                cov_gyr_ * (N - 1.0) / N + (cur_gyr - mean_gyr_).cwiseProduct(cur_gyr - mean_gyr_) * (N - 1.0) / (N * N);

            N++;
        }
        StateIkfom init_state = kf_state.get_x();
        init_state.grav = S2(-mean_acc_ / mean_acc_.norm() * common::G_m_s2);

        ROS_WARN_STREAM("gra is: " << init_state.grav);
        ROS_WARN_STREAM("bg is: "  << init_state.bg);
        ROS_WARN_STREAM("ba is: "  << init_state.ba);
        ROS_WARN_STREAM("pos is: "  << init_state.pos);
        
        init_state.bg = mean_gyr_;
        init_state.pos = Init_IMU_POS_;
        init_state.offset_T_L_I = Lidar_T_wrt_IMU_;
        init_state.offset_R_L_I = Lidar_R_wrt_IMU_;
        kf_state.change_x(init_state);

        ESKF::cov init_P = kf_state.get_P();
        init_P.setIdentity();

        init_P(0, 0) = init_state_cov_.position[0];
        init_P(1, 1) = init_state_cov_.position[1];
        init_P(2, 2) = init_state_cov_.position[2];

        init_P(3, 3) = init_state_cov_.rotation[0];
        init_P(4, 4) = init_state_cov_.rotation[1];
        init_P(5, 5) = init_state_cov_.rotation[2]; 

        init_P(6, 6) = init_state_cov_.extrinsic_R_L_I[0]; 
        init_P(7, 7) = init_state_cov_.extrinsic_R_L_I[1];
        init_P(8, 8) = init_state_cov_.extrinsic_R_L_I[2];

        init_P(9, 9) = init_state_cov_.extrinsic_T_L_I[0]; 
        init_P(10, 10) = init_state_cov_.extrinsic_T_L_I[1];
        init_P(11, 11) = init_state_cov_.extrinsic_T_L_I[2];

        init_P(12, 12) = init_state_cov_.velocity[0]; 
        init_P(13, 13) = init_state_cov_.velocity[1];
        init_P(14, 14) = init_state_cov_.velocity[2];

        init_P(15, 15) = init_state_cov_.bg[0]; 
        init_P(16, 16) = init_state_cov_.bg[1];
        init_P(17, 17) = init_state_cov_.bg[2];

        init_P(18, 18) = init_state_cov_.ba[0]; 
        init_P(19, 19) = init_state_cov_.ba[1];
        init_P(20, 20) = init_state_cov_.ba[2];

        init_P(21,21) = init_state_cov_.gravity[0];
        init_P(22,22) = init_state_cov_.gravity[1];

        kf_state.change_P(init_P);
        last_imu_ = meas.imu_.back();
    }

    void ImuProcess::InitQ() {
        Q_.block<3, 3>(0, 0).diagonal() = cov_gyr_;
        Q_.block<3, 3>(3, 3).diagonal() = cov_acc_;
        Q_.block<3, 3>(6, 6).diagonal() = cov_bias_gyr_;
        Q_.block<3, 3>(9, 9).diagonal() = cov_bias_acc_;
    }

    void ImuProcess::EastIMUInit(const common::MeasureGroup &meas, int &N) {
        common::V3D cur_acc, cur_gyr;

        if (b_first_frame_) {
            Reset();
            N = 1;
            b_first_frame_ = false;
            const auto &imu_acc = meas.imu_.front()->linear_acceleration;
            const auto &gyr_acc = meas.imu_.front()->angular_velocity;
            mean_acc_ << imu_acc.x, imu_acc.y, imu_acc.z;
            mean_gyr_ << gyr_acc.x, gyr_acc.y, gyr_acc.z;
        }

        for (const auto &imu : meas.imu_) {
            const auto &imu_acc = imu->linear_acceleration;
            const auto &gyr_acc = imu->angular_velocity;
            cur_acc << imu_acc.x, imu_acc.y, imu_acc.z;
            cur_gyr << gyr_acc.x, gyr_acc.y, gyr_acc.z;

            mean_acc_ += (cur_acc - mean_acc_) / N;
            mean_gyr_ += (cur_gyr - mean_gyr_) / N;

            cov_acc_ =
                cov_acc_ * (N - 1.0) / N + (cur_acc - mean_acc_).cwiseProduct(cur_acc - mean_acc_) * (N - 1.0) / (N * N);
            cov_gyr_ =
                cov_gyr_ * (N - 1.0) / N + (cur_gyr - mean_gyr_).cwiseProduct(cur_gyr - mean_gyr_) * (N - 1.0) / (N * N);

            N++;
        }
    }
    
    // void ImuProcess::PredictByImuUntilNow(const common::MeasureGroup &meas, esekfom::esekf<StateIkfom, 12, InputIkfom> &kf_state, double new_kf_time)
    // {
    //     auto v_imu = meas.imu_;
    //     common::V3D angvel_avr, acc_avr;
    //     InputIkfom in;
    //     double dt;
    //     bool first_imu = false;
    //     for (auto it_imu = v_imu.begin(); it_imu < (v_imu.end() - 1); it_imu++)
    //     {
    //         auto &&head = *(it_imu);
    //         auto &&tail = *(it_imu + 1);
    //         dt = tail->header.stamp.toSec() - head->header.stamp.toSec();

    //         if (tail->header.stamp.toSec() < new_kf_time) {
    //             continue;
    //         } else {
    //             if (!first_imu) {
    //                 first_imu = true;
    //                 dt = tail->header.stamp.toSec() - new_kf_time;
    //             }
    //         }

    //         angvel_avr << 0.5 * (head->angular_velocity.x + tail->angular_velocity.x),
    //             0.5 * (head->angular_velocity.y + tail->angular_velocity.y),
    //             0.5 * (head->angular_velocity.z + tail->angular_velocity.z);
    //         acc_avr << 0.5 * (head->linear_acceleration.x + tail->linear_acceleration.x),
    //             0.5 * (head->linear_acceleration.y + tail->linear_acceleration.y),
    //             0.5 * (head->linear_acceleration.z + tail->linear_acceleration.z);

    //         acc_avr = acc_avr * common::G_m_s2 / mean_acc_.norm();

    //         in.acc = acc_avr;
    //         in.gyro = angvel_avr;
    //         kf_state.predict(dt, Q_, in);
    //     }
    // }

    void ImuProcess::PropogateOnce(const common::MeasureGroup &meas, ESKF &kf_state, bool have_odom) 
    {
        if (imu_need_init_) {
            EastIMUInit(meas, init_iter_num_);

            imu_need_init_ = true;

            if (init_iter_num_ > MAX_INI_COUNT) {
                imu_need_init_ = false;

                cov_acc_ = cov_acc_scale_;
                cov_gyr_ = cov_gyr_scale_;
                InitQ();
            }
            return;
        }

        if (!have_odom) return;

        // propogate once
        common::V3D angvel_avr, acc_avr;
        InputIkfom in;
        auto v_imu = meas.imu_;
        auto it_imu = v_imu.end() - 1;
        auto &&head = *(it_imu - 1);
        auto &&tail = *(it_imu);

        angvel_avr << 0.5 * (head->angular_velocity.x + tail->angular_velocity.x),
                      0.5 * (head->angular_velocity.y + tail->angular_velocity.y),
                      0.5 * (head->angular_velocity.z + tail->angular_velocity.z);
        acc_avr << 0.5 * (head->linear_acceleration.x + tail->linear_acceleration.x),
                   0.5 * (head->linear_acceleration.y + tail->linear_acceleration.y),
                   0.5 * (head->linear_acceleration.z + tail->linear_acceleration.z);

        acc_avr = acc_avr * common::G_m_s2 / mean_acc_.norm();

        double dt = tail->header.stamp.toSec() - head->header.stamp.toSec();

        in.acc = acc_avr;
        in.gyro = angvel_avr;
        Q_.block<3, 3>(0, 0).diagonal() = cov_gyr_;
        Q_.block<3, 3>(3, 3).diagonal() = cov_acc_;
        Q_.block<3, 3>(6, 6).diagonal() = cov_bias_gyr_;
        Q_.block<3, 3>(9, 9).diagonal() = cov_bias_acc_;
        kf_state.predict(dt, Q_, in);

        imu_state_ = kf_state.get_x();
        angvel_last_ = angvel_avr - imu_state_.bg;
        acc_s_last_ = imu_state_.rot * (acc_avr - imu_state_.ba);
        for (int i = 0; i < 3; i++) {
            acc_s_last_[i] += imu_state_.grav[i];
        }
    }
};