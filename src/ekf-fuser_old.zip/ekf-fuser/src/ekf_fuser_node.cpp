
#include <eigen3/Eigen/Dense>
#include <ros/ros.h>
#include "ekf_fuser.hpp"

using namespace ekf_fuser;

int main(int argc, char **argv)
{
    ros::init(argc, argv, "ekf_fuser_node");
    ros::NodeHandle handle("~");

    EKFFuser ekffuser(handle);

    ros::spin();

    return 0;
}