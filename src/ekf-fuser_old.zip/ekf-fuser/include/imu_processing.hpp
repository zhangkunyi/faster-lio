#pragma once

#include <nav_msgs/Odometry.h>
#include <sensor_msgs/Imu.h>
#include <cmath>
#include <deque>
#include <fstream>

#include "common_lib.h"
#include "so3_math.h"
#include "use-ikfom.hpp"

namespace ekf_fuser {

    constexpr int MAX_INI_COUNT = 50;

    struct StateCovInit
    {
        std::vector<double> position = std::vector<double>(3);
        std::vector<double> rotation = std::vector<double>(3);
        std::vector<double> extrinsic_R_L_I = std::vector<double>(3);
        std::vector<double> extrinsic_T_L_I = std::vector<double>(3);
        std::vector<double> velocity = std::vector<double>(3);
        std::vector<double> bg = std::vector<double>(3);
        std::vector<double> ba = std::vector<double>(3);
        std::vector<double> gravity = std::vector<double>(2);
    };

    class ImuProcess {
    public:
        EIGEN_MAKE_ALIGNED_OPERATOR_NEW

        ImuProcess();
        ~ImuProcess();
        void Process(const common::MeasureGroup &meas, ESKF &kf_state);
        void Reset();
        void SetInitPos(const common::V3D &pos);
        void SetExtrinsic(const common::V3D &transl, const common::M3D &rot);
        void SetGyrCov(const common::V3D &scaler);
        void SetAccCov(const common::V3D &scaler);
        void SetGyrBiasCov(const common::V3D &b_g);
        void SetAccBiasCov(const common::V3D &b_a);
        void SetInitStateCov(const StateCovInit &state_cov);

        StateIkfom GetImuState();
        common::V3D GetAngVel();
        double GetTimeStamp();
        void PropogateOnce(const common::MeasureGroup &meas, ESKF &kf_state, bool have_odom);
        // void PredictByImuUntilNow(const common::MeasureGroup &meas, const ESKF &kf_state, double new_kf_time);
        void InitQ();

        std::ofstream fout_imu_;
        Eigen::Matrix<double, 12, 12> Q_;
        common::V3D cov_acc_;
        common::V3D cov_gyr_;
        common::V3D cov_acc_scale_;
        common::V3D cov_gyr_scale_;
        common::V3D cov_bias_gyr_;
        common::V3D cov_bias_acc_;

    private:
        void IMUInit(const common::MeasureGroup &meas, ESKF &kf_state, int &N);
        void EastIMUInit(const common::MeasureGroup &meas, int &N);

        sensor_msgs::ImuConstPtr last_imu_;
        std::deque<sensor_msgs::ImuConstPtr> v_imu_;
        std::vector<common::Pose6D> IMUpose_;
        common::M3D Lidar_R_wrt_IMU_;
        common::V3D Lidar_T_wrt_IMU_;
        common::V3D Init_IMU_POS_;
        common::V3D mean_acc_;
        common::V3D mean_gyr_;
        common::V3D angvel_last_;
        common::V3D acc_s_last_;
        double current_time_stamp_sec;
        double last_lidar_end_time_ = 0;
        int init_iter_num_ = 1;
        bool b_first_frame_ = true;
        bool imu_need_init_ = true;
        StateIkfom imu_state_;
        StateCovInit init_state_cov_;
    };
}  // namespace ekf_fuser

