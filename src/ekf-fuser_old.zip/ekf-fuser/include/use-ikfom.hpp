#pragma once

#include "IKFoM_toolkit/esekfom/esekfom.hpp"

namespace ekf_fuser {
    typedef MTK::vect<3, double> vect3;
    typedef MTK::SO3<double> SO3;
    typedef MTK::S2<double, 98090, 10000, 1> S2;
    typedef MTK::vect<1, double> vect1;
    typedef MTK::vect<2, double> vect2;


    MTK_BUILD_MANIFOLD(StateIkfom, 
        ((vect3, pos))
        ((SO3, rot))
        ((SO3, offset_R_L_I))
        ((vect3, offset_T_L_I))
        ((vect3, vel))
        ((vect3, bg))
        ((vect3, ba))
        ((S2, grav)));  // states need to be estimate

    MTK_BUILD_MANIFOLD(InputIkfom, 
        ((vect3, acc))
        ((vect3, gyro)));    // current imu's acc and gyro

    MTK_BUILD_MANIFOLD(MeasurementIkfom, 
        ((vect3, pos))
        ((SO3, rot)));     // other imu's p_wrt_w, rotation_wrt_w given by slam algorithm

    MTK_BUILD_MANIFOLD(ProcessNoiseIkfom, 
        ((vect3, ng))
        ((vect3, na))
        ((vect3, nbg))
        ((vect3, nba)));

    MTK_BUILD_MANIFOLD(MeasurementNoiseIkfom, 
        ((vect3, pos))
        ((vect3, rot)));

    typedef esekfom::esekf<StateIkfom,
                           ProcessNoiseIkfom::DOF,
                           InputIkfom, 
                           MeasurementIkfom,
                           MeasurementNoiseIkfom::DOF> ESKF;

    typedef Eigen::Matrix<double, MeasurementNoiseIkfom::DOF, MeasurementNoiseIkfom::DOF> MeasurementNoiseCov;
    typedef Eigen::Matrix<double, StateIkfom::DOF, StateIkfom::DOF> StateCov;

    MTK::get_cov<ProcessNoiseIkfom>::type process_noise_cov();

    MTK::get_cov<MeasurementNoiseIkfom>::type measurement_noise_cov();

    Eigen::Matrix<double, 24, 1> f(StateIkfom &s, const InputIkfom &in);

    Eigen::Matrix<double, 24, 23> df_dx(StateIkfom &s, const InputIkfom &in);

    Eigen::Matrix<double, 24, 12> df_dw(StateIkfom &s, const InputIkfom &in);

    MeasurementIkfom h(StateIkfom &s, bool &valid);

    Eigen::Matrix<double, MeasurementIkfom::DOF, StateIkfom::DOF> dh_dx(StateIkfom &s, bool &valid);

    Eigen::Matrix<double, MeasurementIkfom::DOF, MeasurementNoiseIkfom::DOF> dh_dv(StateIkfom &s, bool &valid);

    vect3 SO3ToEuler(const SO3 &orient);

}  // namespace ekf_fuser

