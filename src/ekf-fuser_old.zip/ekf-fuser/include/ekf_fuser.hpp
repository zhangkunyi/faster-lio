#ifndef EKF_FUSER_H
#define EKF_FUSER_H

#include <ros/ros.h>
#include "imu_processing.hpp"

#include "ekf_fuser/KF.h"

namespace ekf_fuser {
    class EKFFuser
    {
    private:
        ros::Subscriber sub_kf_;      // receive kf messge to refresh the kf member. 
        ros::Subscriber sub_imu_;     // receive imu and propagrate from current kf status.

        ros::Publisher pub_odom_;
        ros::Publisher pub_state_;

        std::shared_ptr<ekf_fuser::ImuProcess> p_imu_ = nullptr;

        ESKF kf_;

        double timediff_lidar_wrt_imu_ = 0;

        bool have_lidar_odom_ = false;

        common::MeasureGroup measures_;

        int MAX_IMU_COUNT_ = 30;

        common::V3D last_pos_center_{0, 0, 0};
        
        common::V3D last_last_pos_center_{0, 0, 0};

    public:
        EKFFuser(ros::NodeHandle &handle);

        void MeasureCallBack(const nav_msgs::Odometry::ConstPtr & odom_msg);

        void IMUCallBack(const sensor_msgs::Imu::ConstPtr &msg_in);

        void publishState(const StateIkfom & x, const StateCov & P, double time_stamp);

        void publishOdom(nav_msgs::Odometry & odom_pub_msg);

        void filter(nav_msgs::Odometry &odom_fake_ekf, common::V3D pos);
    };
}

#endif